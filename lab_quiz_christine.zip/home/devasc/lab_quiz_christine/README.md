This project is for quiz and graded activity.
